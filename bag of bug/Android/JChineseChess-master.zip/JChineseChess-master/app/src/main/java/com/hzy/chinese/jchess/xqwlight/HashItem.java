package com.hzy.chinese.jchess.xqwlight;

/**
 * Created by HZY on 2018/3/8.
 */
class HashItem {
    byte depth, flag;
    short vl;
    int mv, zobristLock;
}
