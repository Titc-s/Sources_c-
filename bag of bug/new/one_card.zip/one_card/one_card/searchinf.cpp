#include "searchinf.h"

SearchInf::SearchInf(QWidget *parent) : QWidget(parent)
{

}
