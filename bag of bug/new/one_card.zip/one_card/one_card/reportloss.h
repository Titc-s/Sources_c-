#ifndef REPORTLOSS_H
#define REPORTLOSS_H

#include <QWidget>

class ReportLoss : public QWidget
{
    Q_OBJECT
public:
    explicit ReportLoss(QWidget *parent = nullptr);

signals:

};

#endif // REPORTLOSS_H
