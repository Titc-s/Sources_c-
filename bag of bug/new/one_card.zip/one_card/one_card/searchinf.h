#ifndef SEARCHINF_H
#define SEARCHINF_H

#include <QWidget>
#include <QPushButton>
#include <QTextEdit>
#include <QTableWidget>
#include <QTableWidgetItem>

class SearchInf : public QWidget
{
    Q_OBJECT
public:
    explicit SearchInf(QWidget *parent = nullptr);

signals:


private:


};

#endif // SEARCHINF_H
