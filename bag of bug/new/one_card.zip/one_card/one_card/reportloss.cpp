#include "reportloss.h"

ReportLoss::ReportLoss(QWidget *parent) : QWidget(parent)
{

}
